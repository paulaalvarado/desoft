package com.utn.TPJPAAlvarado;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TpjpaAlvaradoApplication {

	public static void main(String[] args) {
		SpringApplication.run(TpjpaAlvaradoApplication.class, args);
	}

}
