package com.utn.TPJPAAlvarado;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TpjpaAlvaradoApplicationTests {

	@Test
	void contextLoads() {
	}

}
